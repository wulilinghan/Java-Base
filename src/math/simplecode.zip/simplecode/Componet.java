package math.simplecode;

import java.util.HashMap;
import java.util.Map;

/**
 * @program: java-base->Componet
 * @description:
 * @author: G_Y
 * @create: 2019-08-28 15:15
 **/
public class Componet {
    public static final Map<String, Handler> map = new HashMap<>(16);

    static {
        map.put("+", Handler.ADD);
        map.put("-", Handler.SUBTRACTION);
    }
}
