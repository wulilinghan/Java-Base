package math.simplecode;

import java.util.Scanner;

/**
 * @program: java-base->SimpleTest
 * @description:
 * @author: G_Y
 * @create: 2019-08-28 15:14
 **/
public class SimpleTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        String c = sc.next();
        int b = sc.nextInt();
        //...
        int result = Componet.map.get(c).excute(a, b);
        System.out.println(result);
    }
}
